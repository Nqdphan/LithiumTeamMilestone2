Library Management System (CS 4347 Milestone 2)

Instructions

Add a file named .env in the project directory containing the following lines:

DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=library
Replace the value of DB_PASSWORD, your_mysql_password, with your MySQL password.

Once the .env file has been added, run main.py using Python 3.

Team members

Sarayu Gajula (sxg220241)
Gaurav Jena (gxj220015)
Nguyen Quoc Dung Phan (nxp230046)
Armaan Metalwala (axm240102)
Rishi Anand Nambair (ran220001)
